<style>
.sidebar {
    width: 250px;
    height: 100%;
    background: #007bff;
    position: fixed;
    top: 130px;
}

.sidebar a {
    display: block;
    color: white;
    padding: 12px 20px;
    text-decoration: none;
    font-size: 18px;
    transition: 0.3s;
}

.sidebar a:hover {
    background: #0056b3;
}
</style>

    <div class="sidebar">
    <a href="../index.php">Home</a>
    <a href="user_dashboard.php">Dashboard</a>
    <a href="view_branches.php">View Branches</a>
    <a href="view_children.php">View Children</a>
    <a href="apply_adoption.php">Apply for Adoption</a>
    <a href="donate.php">Donate</a>
    <a href="user_profile.php">Profile</a>
    </div>

