<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}

include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $child_id = intval($_POST['child_id']);
    $user_id = intval($_SESSION['user_id']);

    // Validate user_id exists in users table
    $user_check = $conn->query("SELECT id FROM users WHERE id = $user_id");
    if ($user_check->num_rows === 0) {
        $message = "Error: User does not exist.";
    } else {
        // Check if child is available
        $check = $conn->query("SELECT adoption_status FROM children WHERE id = $child_id");
        $child = $check->fetch_assoc();

        if ($child && $child['adoption_status'] == 'Available') {
            // Insert adoption request safely
            $stmt = $conn->prepare("INSERT INTO adoption_requests (user_id, child_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $user_id, $child_id);
            if ($stmt->execute()) {
                $message = "Adoption request submitted successfully!";
            } else {
                $message = "Error: Could not submit request.";
            }
            $stmt->close();
        } else {
            $message = "This child is already adopted or does not exist.";
        }
    }
}

// Get available children
$children = $conn->query("SELECT * FROM children WHERE adoption_status = 'Available'");
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container">
        <h2>Apply for Adoption</h2>
        <?php if (isset($message)) { ?>
            <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
        <?php } ?>
        <form method="post">
            <div class="mb-3">
                <label>Select a Child:</label>
                <select name="child_id" class="form-control" required>
                    <option value="">-- Select --</option>
                    <?php while ($child = $children->fetch_assoc()) { ?>
                        <option value="<?= $child['id'] ?>"><?= htmlspecialchars($child['name']) ?> (Age: <?= $child['age'] ?>)</option>
                    <?php } ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Submit Adoption Request</button>
        </form>
    </div>
<?php
include "footer.php";
?>
