<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}
include '../db.php';

$result = $conn->query("SELECT * FROM children");
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container">
        <h2>Children Available for Adoption</h2>
        <div class="row">
            <?php while ($child = $result->fetch_assoc()) { ?>
                <div class="col-md-4">
                    <div class="card">
                        <img src="../uploads/<?= $child['photo'] ?>" class="card-img-top" alt="<?= $child['name'] ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= $child['name'] ?></h5>
                            <p class="card-text">Age: <?= $child['age'] ?></p>
                            <p class="card-text"><strong>Status:</strong> 
                                <span class="badge bg-<?= $child['adoption_status'] == 'Available' ? 'success' : 'danger' ?>">
                                    <?= $child['adoption_status'] ?>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
<?php
include "footer.php";
?>