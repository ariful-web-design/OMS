<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}

include '../db.php';

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Fetch user's total donations
$donationQuery = "SELECT SUM(amount) AS total_donations FROM donations WHERE user_id = ?";
$stmt = $conn->prepare($donationQuery);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$donationData = $result->fetch_assoc();
$totalDonations = $donationData['total_donations'] ?? 0;

// Fetch user's adoption status
$adoptionQuery = "SELECT status FROM adoption_requests WHERE user_id = ? ORDER BY applied_at DESC LIMIT 1";
$stmt = $conn->prepare($adoptionQuery);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$adoptionData = $result->fetch_assoc();
$adoptionStatus = $adoptionData['status'] ?? 'No Adoption Request';
?>
<?php include "header.php"; ?>
<div>
    <?php include "sidebar.php"; ?>
</div>

<div class="container mt-4">
    <h2>Welcome, <?= htmlspecialchars($username) ?>!</h2>
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">My Total Donations</h5>
                    <p class="card-text">৳ <?= number_format($totalDonations, 2) ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Adoption Status</h5>
                    <p class="card-text"> <?= htmlspecialchars($adoptionStatus) ?> </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
