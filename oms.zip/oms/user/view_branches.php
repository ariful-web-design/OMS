<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}
include '../db.php';

// Fetch branches along with total needs amount from needs table
$query = "
    SELECT 
        b.id, b.name, b.location, b.total_children, b.total_donations, 
        COALESCE(SUM(n.amount), 0) AS total_amount_needed
    FROM branches b
    LEFT JOIN needs n ON b.id = n.branch_id
    GROUP BY b.id
";
$result = $conn->query($query);
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container mt-5">
        <h2>Orphanage Branches</h2>
        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Name</th>
                    <th>Location</th>
                    <th>Total Children</th>
                    <th>Total Needs (Amount)</th>
                    <th>Total Donations</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($branch = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= htmlspecialchars($branch['name']) ?></td>
                        <td><?= htmlspecialchars($branch['location']) ?></td>
                        <td><?= $branch['total_children'] ?></td>
                        <td>BDT <?= number_format($branch['total_amount_needed'], 2) ?></td>  <!-- Updated Field -->
                        <td>BDT <?= number_format($branch['total_donations'], 2) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
<?php
include "footer.php";
?>