<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}
include '../db.php';

$user_id = $_SESSION['user_id'];
$conn->query("DELETE FROM users WHERE id = $user_id");
session_destroy();
header("Location: user_signup.php");
?>
