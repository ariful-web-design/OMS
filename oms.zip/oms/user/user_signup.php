<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check for duplicate username or email
    $check = $conn->query("SELECT * FROM users WHERE email='$email' OR username='$username'");
    if ($check->num_rows > 0) {
        echo "<script>alert('Username or Email already exists!');</script>";
    } else {
        $conn->query("INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')");
        header("Location: user_login.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .signup-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-control {
            padding-left: 2.5rem;
        }
        .input-group-text {
            background: none;
            border: none;
        }
        .password-hint {
            font-size: 0.9rem;
            color: #6c757d;
        }
    </style>
    <script>
        function validatePassword() {
            const password = document.getElementById('password');
            const hint = document.getElementById('password-hint');
            const regex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;
            
            if (!regex.test(password.value)) {
                password.setCustomValidity('Password must be at least 6 characters long and include at least one letter, one number, and one special character.');
                hint.style.color = 'red';
            } else {
                password.setCustomValidity('');
                hint.style.color = '#6c757d';
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="signup-container">
            <h3 class="text-center mb-4">Create an Account</h3>
            <form method="post">
                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                    <input type="text" name="username" class="form-control" placeholder="Username" required>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    <input type="email" name="email" class="form-control" placeholder="Email" required>
                </div>
                <div class="input-group mb-3">
    <span class="input-group-text"><i class="fas fa-phone"></i></span>
    <input 
        type="tel" 
        name="phone" 
        class="form-control" 
        placeholder="Phone (e.g. 017xxxxxxxx)" 
        pattern="^(017|016|013|019|014|018)[0-9]{8}$" 
        required 
        title="Phone number must start with 017, 016, 013, 019, 014, or 018 and be 11 digits long"
    >
</div>

                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password" required oninput="validatePassword()">
                </div>
                <p id="password-hint" class="password-hint">Password must be at least 6 characters long and include at least one letter, one number, and one special character.</p>
                <button type="submit" class="btn btn-primary w-100">Sign Up</button>
            </form><br>
            <div>
                <h6>If you are an user, then go to login</h6><br>
                <a href="user_login.php">
                <button type="submit" class="btn btn-warning w-50">Login</button></a>
            </div>
        </div>
    </div>
</body>
</html>
