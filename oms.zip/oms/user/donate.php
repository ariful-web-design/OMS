<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $branch_id = $_POST['branch_id'];
    $amount = $_POST['amount'];
    $user_id = $_SESSION['user_id'];

    if ($amount > 0) {
        // Insert donation record
        $conn->query("INSERT INTO donations (user_id, branch_id, amount) VALUES ($user_id, $branch_id, $amount)");
        $message = "Thank you for your donation!";
    } else {
        $message = "Donation amount must be greater than zero.";
    }
}

// Get branches
$branches = $conn->query("SELECT * FROM branches");
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container">
        <h2>Donate to an Orphanage Branch</h2>
        <?php if (isset($message)) { ?>
            <div class="alert alert-info"><?= $message ?></div>
        <?php } ?>
        <form method="post">
            <div class="mb-3">
                <label>Select Branch:</label>
                <select name="branch_id" class="form-control" required>
                    <option value="">-- Select --</option>
                    <?php while ($branch = $branches->fetch_assoc()) { ?>
                        <option value="<?= $branch['id'] ?>"><?= $branch['name'] ?> (<?= $branch['location'] ?>)</option>
                    <?php } ?>
                </select>
            </div>
            <div class="mb-3">
                <label>Amount (BDT):</label>
                <input type="number" name="amount" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Donate</button>
        </form>
    </div>
<?php
include "footer.php";
?>
