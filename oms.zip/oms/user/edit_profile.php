<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}
include '../db.php';

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM users WHERE id = $user_id");
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $conn->query("UPDATE users SET username='$username', email='$email', phone='$phone' WHERE id=$user_id");
    $_SESSION['message'] = "Profile updated successfully!";
    header("Location: user_profile.php");
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container">
        <h2>Edit Profile</h2>
        <form method="post">
            <div class="mb-3">
                <label>Username:</label>
                <input type="text" name="username" value="<?= $user['username'] ?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Email:</label>
                <input type="email" name="email" value="<?= $user['email'] ?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Phone:</label>
                <input type="text" name="phone" value="<?= $user['phone'] ?>" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Profile</button>
        </form>
        <a href="user_profile.php" class="btn btn-secondary mt-3">Back</a>
    </div>
<?php
include "footer.php";
?>