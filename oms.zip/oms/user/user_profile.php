<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}
include '../db.php';

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM users WHERE id = $user_id");

// Debugging line
if (!$result) {
    die("Query failed: " . $conn->error);
}

$user = $result->fetch_assoc();

// Debugging line
if (!$user) {
    die("User not found.");
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>

    <div class="container">
        <h2>User Profile</h2>
        <table class="table">
            <tr><th>Name:</th><td><?= htmlspecialchars($user['username']) ?></td></tr>
            <tr><th>Email:</th><td><?= htmlspecialchars($user['email']) ?></td></tr>
            <tr><th>Phone:</th><td><?= htmlspecialchars($user['phone']) ?></td></tr>
        </table>
        <a href="edit_profile.php" class="btn btn-warning">Edit Profile</a>
        <a href="delete_profile.php" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete Account</a>
    </div>
<?php
include "footer.php";
?>
