<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Martri Chaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}
.te{
   background-color: #010b1569;
}
/* HEADER */
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #007bff;
    padding: 15px 20px;
    color: white;
}

.logo img {
            height: 100px;
            width: 100px;
            border-radius: 50%;
            border: 6px solid black;
        }

.logout-btn {
    background: darkred;
    color: #007bff;
    padding: 8px 15px;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
}

.logout-btn:hover {
    background: #0056b3;
    color: white;
}
</style>
<body>
    <header class="header">
        <div class="logo">
            <img src="logoo.png" alt="OMS Logo">
        </div>
        <h2 class="te">Matri Chaya User Panel</h2>
        <div class="logout">
            <a href="user_logout.php" class="logout-btn">Logout</a>
        </div>
    </header>

