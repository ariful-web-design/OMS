<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'branch') {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

$branch_id = $_SESSION['user_id']; // Use user_id as branch_id

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = $conn->query("SELECT * FROM children WHERE id = $id");
    $child = $query->fetch_assoc();

    if (!$child) {
        echo "Child not found!";
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $photo = $child['photo']; // Keep existing photo if no new file is uploaded

    // Handle file upload
    if (!empty($_FILES['photo']['name'])) {
        $upload_dir = "../uploads/";
        $filename = time() . "_" . basename($_FILES['photo']['name']);
        $target_file = $upload_dir . $filename;

        // Ensure uploads folder exists
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Move file and update photo variable
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
            $photo = $filename;
        } else {
            echo "<script>alert('File upload failed!');</script>";
        }
    }

    // Update child information in the database
    $stmt = $conn->prepare("UPDATE children SET name=?, age=?, gender=?, photo=? WHERE id=?");
    $stmt->bind_param("sissi", $name, $age, $gender, $photo, $id);
    $stmt->execute();

    header("Location: manage_children.php");
    exit();
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container">
        <h2>Edit Child</h2>
        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="name" value="<?= htmlspecialchars($child['name']) ?>" class="form-control" required><br>
            <input type="number" name="age" value="<?= $child['age'] ?>" class="form-control" required><br>
            <select name="gender" class="form-control" required>
                <option value="Male" <?= $child['gender'] == 'Male' ? 'selected' : '' ?>>Male</option>
                <option value="Female" <?= $child['gender'] == 'Female' ? 'selected' : '' ?>>Female</option>
            </select><br>
            <label>Current Photo:</label><br>
            <img src="../uploads/<?= htmlspecialchars($child['photo']) ?>" width="100" height="100" alt="Child Photo"><br><br>
            <label>Upload New Photo (Optional):</label>
            <input type="file" name="photo" class="form-control"><br>
            <button type="submit" class="btn btn-warning">Update Child</button>
        </form>
    </div>
<?php
include "footer.php";
?>