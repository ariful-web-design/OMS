<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'branch') {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

$branch_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Fetch branch details securely
$stmt = $conn->prepare("SELECT total_children, total_needs, total_donations FROM branches WHERE id = ?");
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result = $stmt->get_result();
$branch = $result->fetch_assoc();
$stmt->close();
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container mt-5">
        <h2>Welcome Branch Manager, <?php echo htmlspecialchars($username); ?>!</h2>

        <div class="card mt-4 shadow-sm border-0">
    <div class="card-body p-4">
        <h5 class="card-title text-primary fw-bold">Dashboard Summary</h5>
        <hr>
        <div class="row">
            <div class="col-md-4">
                <div class="bg-light p-3 rounded text-center">
                    <h6 class="text-muted">Total Children</h6>
                    <p class="fs-5 fw-semibold text-dark"><?php echo htmlspecialchars($branch['total_children'] ?? '0'); ?></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="bg-light p-3 rounded text-center">
                    <h6 class="text-muted">Total Needs</h6>
                    <p class="fs-5 fw-semibold text-dark"><?php echo htmlspecialchars($branch['total_needs'] ?? '0'); ?></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="bg-light p-3 rounded text-center">
                    <h6 class="text-muted">Total Donations</h6>
                    <p class="fs-5 fw-semibold text-dark"><?php echo htmlspecialchars($branch['total_donations'] ?? '0'); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

    </div>
<?php
include "footer.php";
?>
