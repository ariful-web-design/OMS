<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

$branch_id = $_SESSION['user_id'];
$result = $conn->query("SELECT d.id, u.username, d.amount, d.donation_date, d.status 
                        FROM donations d
                        JOIN users u ON d.user_id = u.id
                        WHERE d.branch_id = $branch_id");
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>

    <div class="container">
        <h2>View Donations</h2>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Donor</th>
                    <th>Amount</th>
                    <th>Donation Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['username'] ?></td>
                        <td>$<?= $row['amount'] ?></td>
                        <td><?= $row['donation_date'] ?></td>
                        <td><?= $row['status'] ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
<?php
include "footer.php";
?>