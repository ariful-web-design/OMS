<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'branch') {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

$branch_id = $_SESSION['user_id']; // Use user_id as branch_id

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $age = intval($_POST['age']);
    $gender = $_POST['gender'];

    if (!in_array($gender, ['Male', 'Female'])) {
        die("Invalid gender selection!");
    }

    // File upload handling
    $photo = "default.png"; // Default image
    if (!empty($_FILES['photo']['name'])) {
        $upload_dir = "../uploads/";
        $filename = time() . "_" . basename($_FILES['photo']['name']);
        $target_file = $upload_dir . $filename;

        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
            $photo = $filename; // Save filename only
        }
    }

    // Insert child into the database using prepared statement
    $stmt = $conn->prepare("INSERT INTO children (branch_id, name, age, gender, photo) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }
    
    $stmt->bind_param("isiss", $branch_id, $name, $age, $gender, $photo);
    if (!$stmt->execute()) {
        die("Execution Error: " . $stmt->error);
    }

    // Update branch child count
    $update_stmt = $conn->prepare("UPDATE branches SET total_children = total_children + 1 WHERE id = ?");
    $update_stmt->bind_param("i", $branch_id);
    $update_stmt->execute();

    header("Location: manage_children.php");
    exit();
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container mt-5">
        <h2>Add New Child</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <input type="text" name="name" class="form-control" placeholder="Child Name" required>
            </div>
            <div class="mb-3">
                <input type="number" name="age" class="form-control" placeholder="Age" required>
            </div>
            <div class="mb-3">
                <select name="gender" class="form-control" required>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div class="mb-3">
                <input type="file" name="photo" class="form-control">
            </div>
            <button type="submit" class="btn btn-success">Add Child</button>
        </form>
    </div>
<?php
include "footer.php";
?>
