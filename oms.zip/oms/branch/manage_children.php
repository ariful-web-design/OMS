<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'branch') {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

$branch_id = $_SESSION['user_id']; // Use user_id for branch role

// Ensure branch_id is valid before running the query
if (!is_numeric($branch_id)) {
    die("Invalid branch ID");
}

// Fetch children associated with the branch
$stmt = $conn->prepare("SELECT * FROM children WHERE branch_id = ?");
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result = $stmt->get_result();
?>


<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container">
        <h2>Manage Children</h2>
        <a href="add_child.php" class="btn btn-primary">Add Child</a>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Photo</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Adoption Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($child = $result->fetch_assoc()): ?>
                    <tr>
                        <td> <img src="../uploads/<?= htmlspecialchars($child['photo']) ?>" width="100" height="100" alt="Child Photo" onerror="this.onerror=null; this.src='../uploads/default.png';">
                        </td></td>
                        <td><?= $child['name'] ?></td>
                        <td><?= $child['age'] ?></td>
                        <td><?= $child['gender'] ?></td>
                        <td><?= $child['adoption_status'] ?></td>
                        <td>
                            <a href="edit_child.php?id=<?= $child['id'] ?>" class="btn btn-warning">Edit</a>
                            <a href="delete_child.php?id=<?= $child['id'] ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
<?php
include "footer.php";
?>