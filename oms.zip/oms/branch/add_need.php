<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'branch') {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

$branch_id = $_SESSION['user_id']; // Use user_id as branch_id

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $branch_id = $_SESSION['user_id'];
    $child_id = !empty($_POST['child_id']) ? intval($_POST['child_id']) : NULL; // Optional child ID
    $need_type = $_POST['need_type']; // Must match ENUM values
    $description = $_POST['description'];
    $amount = floatval($_POST['amount']); // Correct column name

    // Validate need_type (should match ENUM values)
    $valid_types = ['Food', 'Education', 'Maintenance'];
    if (!in_array($need_type, $valid_types)) {
        die("Invalid need type selected.");
    }

    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO needs (branch_id, child_id, need_type, description, amount) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iissd", $branch_id, $child_id, $need_type, $description, $amount);

    if ($stmt->execute()) {
        header("Location: manage_needs.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container">
        <h2>Add New Need</h2>
        <form method="POST">
            <select name="need_type" class="form-control" required>
                <option value="">Select Need Type</option>
                <option value="Food">Food</option>
                <option value="Education">Education</option>
                <option value="Maintenance">Maintenance</option>
            </select><br>
            
            <textarea name="description" class="form-control" placeholder="Description" required></textarea><br>
            
            <input type="number" step="0.01" name="amount" class="form-control" placeholder="Amount Needed (e.g., 500.00)" required><br>
            

            <button type="submit" class="btn btn-success">Add Need</button>
        </form>
    </div>
<?php
include "footer.php";
?>