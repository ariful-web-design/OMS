<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'branch') {
    header("Location: branch_login.php");
    exit();
}
include '../db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = $conn->query("SELECT * FROM needs WHERE id = $id");
    $need = $query->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $description = $_POST['description'];
    $amount = $_POST['amount'];
    $need_type = $_POST['need_type'];

    $stmt = $conn->prepare("UPDATE needs SET description=?, amount=?, need_type=? WHERE id=?");
    $stmt->bind_param("sdsi", $description, $amount, $need_type, $id);
    $stmt->execute();

    header("Location: manage_needs.php");
    exit();
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container">
        <h2>Edit Need</h2>
        <form method="POST">
            <input type="text" name="description" value="<?= $need['description'] ?>" class="form-control" required><br>
            <input type="number" name="amount" step="0.01" value="<?= $need['amount'] ?>" class="form-control" required><br>
            <select name="need_type" class="form-control" required>
                <option value="Food" <?= $need['need_type'] == 'Food' ? 'selected' : '' ?>>Food</option>
                <option value="Education" <?= $need['need_type'] == 'Education' ? 'selected' : '' ?>>Education</option>
                <option value="Medical" <?= $need['need_type'] == 'Medical' ? 'selected' : '' ?>>Medical</option>
                <option value="Maintenance" <?= $need['need_type'] == 'Maintenance' ? 'selected' : '' ?>>Maintenance</option>
            </select><br>
            <button type="submit" class="btn btn-warning">Update Need</button>
        </form>
    </div>
<?php
include "footer.php";
?>
