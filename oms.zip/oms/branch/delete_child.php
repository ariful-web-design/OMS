<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conn->query("DELETE FROM children WHERE id = $id");

    // Update child count
    $conn->query("UPDATE branches SET total_children = total_children - 1 WHERE id = {$_SESSION['user_id']}");

    header("Location: manage_children.php");
    exit();
}
?>
