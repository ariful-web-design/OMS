<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

$branch_id = $_SESSION['user_id'];
$result = $conn->query("SELECT ar.id, u.username, c.name AS child_name, ar.status, ar.applied_at 
                        FROM adoption_requests ar
                        JOIN users u ON ar.user_id = u.id
                        JOIN children c ON ar.child_id = c.id
                        WHERE ar.branch_id = $branch_id");
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container">
        <h2>Track Adoption Requests</h2>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Applicant</th>
                    <th>Child</th>
                    <th>Status</th>
                    <th>Applied On</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['username'] ?></td>
                        <td><?= $row['child_name'] ?></td>
                        <td><?= $row['status'] ?></td>
                        <td><?= $row['applied_at'] ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
<?php
include "footer.php";
?>
