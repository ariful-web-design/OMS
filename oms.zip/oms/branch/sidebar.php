<style>
.sidebar {
    width: 250px;
    height: 100%;
    background: #007bff;
    position: fixed;
    top: 120px;
}

.sidebar a {
    display: block;
    color: white;
    padding: 12px 20px;
    text-decoration: none;
    font-size: 18px;
    transition: 0.3s;
}

.sidebar a:hover {
    background: #0056b3;
}
</style>

    <div class="sidebar">
    <a href="branch_dashboard.php">Dashboard</a>
    <a href="manage_children.php">Manage Children</a>
    <a href="manage_needs.php">Manage Needs</a>
    <a href="track_adoptions.php">Adoptions Report</a>
    <a href="manage_donations.php">Donations</a>
    <a href="view_children.php">View Child</a>
    </div>

