<style>
.footer {
    text-align: center;
    background: #007bff;
    color: white;
    padding: 10px;
    position: fixed;
    bottom: 0;
    width: 100%;
}

</style>
 <footer class="footer">
        <p>&copy; 2025 Matri Chaya. All Rights Reserved.</p>
    </footer>
</body>
</html>
