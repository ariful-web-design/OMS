<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'branch') {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

$branch_id = $_SESSION['user_id']; // Corrected usage

// Secure query using prepared statements
$stmt = $conn->prepare("SELECT * FROM needs WHERE branch_id = ?");
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container mt-5">
        <h2>Manage Needs</h2>
        <a href="add_need.php" class="btn btn-primary">Add Need</a>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Amount Needed</th>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($need = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($need['description']) ?></td>
                        <td>BDT <?= number_format($need['amount'], 2) ?></td>
                        <td><?= htmlspecialchars($need['need_type']) ?></td>
                        <td>
                            <a href="edit_need.php?id=<?= $need['id'] ?>" class="btn btn-warning">Edit</a>
                            <a href="delete_need.php?id=<?= $need['id'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this need?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
<?php
include "footer.php";
?>