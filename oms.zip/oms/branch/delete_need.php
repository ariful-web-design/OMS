<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conn->query("DELETE FROM needs WHERE id = $id");

    // Update total needs count
    $conn->query("UPDATE branches SET total_needs = total_needs - 1 WHERE id = {$_SESSION['user_id']}");

    header("Location: manage_needs.php");
    exit();
}
?>
