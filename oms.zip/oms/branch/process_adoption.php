<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: branch_login.php");
    exit();
}

include '../db.php';

if (isset($_GET['id']) && isset($_GET['action'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    if ($action == 'approve') {
        $conn->query("UPDATE adoption_requests SET status='Approved', approved_at=NOW() WHERE id=$id");
    } elseif ($action == 'reject') {
        $conn->query("UPDATE adoption_requests SET status='Rejected' WHERE id=$id");
    }

    header("Location: track_adoptions.php");
    exit();
}
?>
