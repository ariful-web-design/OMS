<?php
include 'db.php';

$sql = "SELECT id, media_type, media_url, posted_at FROM gallery ORDER BY posted_at DESC";
$result = $conn->query($sql);

$gallery = [];
while ($row = $result->fetch_assoc()) {
    $gallery[] = $row;
}

echo json_encode($gallery);
?>
