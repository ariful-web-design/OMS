<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Color Buttons</title>
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            text-align: center;
        }

        .button {
            width: 200px;
            height: 100px;
            font-size: 24px;
            border: none;
            border-radius: 8px;
            color: white;
            cursor: pointer;
            margin: 15px;
            transition: transform 0.3s ease;
        }

        .button:hover {
            transform: scale(1.1);
        }

        .btn-red {
            background-color: #ff4c4c;
        }

        .btn-blue {
            background-color: #007bff;
        }

        .btn-green {
            background-color: #28a745;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Please select your Role for Login</h1>
        <a href="admin/admin_login.php">
        <button class="button btn-red" >Admin</button></a>
        <a href="branch/branch_login.php">
        <button class="button btn-blue">Branch</button></a>
        <a href="user/user_login.php">
        <button class="button btn-green">User</button></a>
    </div>
    <script>
        document.querySelector('.btn-red').addEventListener('click', function() {
        alert('If you are admin, click on OK');
       });
        document.querySelector('.btn-blue').addEventListener('click', function() {
        alert('If you are branch manager, click on OK');
       });
        document.querySelector('.btn-green').addEventListener('click', function() {
        alert('If you are user, click on OK');
       });
    </script>
</body>
</html>
