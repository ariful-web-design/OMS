<style>
.sidebar {
    width: 200px;
    height: 100%;
    background: #007bff;
    position: fixed;
    top: 115px;
}

.sidebar a {
    display: block;
    color: white;
    padding: 12px 20px;
    text-decoration: none;
    font-size: 18px;
    transition: 0.3s;
}

.sidebar a:hover {
    background: #0056b3;
}
</style>

    <div class="sidebar">
    <a href="#news">Update News</a>
    <a href="#notice">Notice</a>
    <a href="#gallery">Gallery</a>
    <a href="login.php">Login</a>
    <a href="user/user_signup.php">Signup</a>
    </div>

