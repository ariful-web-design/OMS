<?php
include 'db.php';

$sql = "SELECT id, title, content, posted_at FROM news ORDER BY posted_at DESC";
$result = $conn->query($sql);

$news = [];
while ($row = $result->fetch_assoc()) {
    $news[] = $row;
}

echo json_encode($news);
?>
