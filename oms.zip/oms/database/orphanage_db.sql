-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2025 at 12:57 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orphanage_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`) VALUES
(2, 'Eftekhar Anam', 'anam@mc.org', '63fc7ee703bfa0ea90581bde45431b0c1d7432b2609322d3278be2d34794b473');

-- --------------------------------------------------------

--
-- Table structure for table `adoption_requests`
--

CREATE TABLE `adoption_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `child_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  `decided_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` text NOT NULL,
  `total_children` int(11) DEFAULT 0,
  `total_needs` int(11) DEFAULT 0,
  `total_donations` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `name`, `location`, `total_children`, `total_needs`, `total_donations`, `created_at`) VALUES
(5, 'Rajshahi Branch', 'Zero point,Rajshahi', 0, 0, '0.00', '2025-04-14 04:25:50'),
(6, 'Dhaka Branch', '1/16 North Asad Gate Mirpur Rd, Dhaka', 0, 0, '0.00', '2025-04-14 04:29:48'),
(7, 'Khulna Branch', 'Dhaka-Jessore Hwy, Khulna', 0, 0, '0.00', '2025-04-14 04:32:08'),
(8, 'Mymensing Branch', 'Pondit Para Rd, Mymensing', 0, 0, '0.00', '2025-04-14 04:34:03'),
(9, 'Chattogram Branch', 'Jamal Khan Rd, Chattogram', 0, 0, '0.00', '2025-04-14 04:35:45'),
(10, 'Rangpur Branch', 'Dinajpur-Phulbari Rd, Rangpur', 0, 0, '0.00', '2025-04-14 04:37:27'),
(11, 'Barisal Branch', 'BM College Rd, Barisal', 3, 0, '0.00', '2025-04-14 04:39:51'),
(12, 'Shylet Branch', 'Dariapara Rd, Shylet', 0, 0, '0.00', '2025-04-14 04:42:16');

-- --------------------------------------------------------

--
-- Table structure for table `branch_admin`
--

CREATE TABLE `branch_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `children`
--

CREATE TABLE `children` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `adoption_status` enum('Available','Adopted') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `children`
--

INSERT INTO `children` (`id`, `branch_id`, `name`, `age`, `gender`, `photo`, `adoption_status`, `created_at`) VALUES
(5, 11, 'Nisha', 8, 'Female', '1744609177_images.jpg', 'Available', '2025-04-14 05:39:37'),
(6, 11, 'Maya', 7, 'Female', '1744609214_s.jpg', 'Available', '2025-04-14 05:40:14'),
(7, 11, 'Moni', 9, 'Female', '1744609241_imssages.jpg', 'Available', '2025-04-14 05:40:41');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `donation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `decided_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fund_requests`
--

CREATE TABLE `fund_requests` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `purpose` text NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `approved_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `decided_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `media_type` enum('photo','video') NOT NULL,
  `media_url` varchar(255) NOT NULL,
  `posted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `media_type`, `media_url`, `posted_at`, `admin_id`) VALUES
(7, 'photo', '../uploads/images.jpg', '2025-04-10 11:20:40', 2),
(8, 'photo', '../uploads/imassges.jpg', '2025-04-10 11:20:44', 2),
(9, 'photo', '../uploads/imssages.jpg', '2025-04-10 11:20:52', 2),
(10, 'photo', '../uploads/India_SOTW1-11-15_lead_resized.jpg', '2025-04-10 11:20:57', 2),
(11, 'photo', '../uploads/iwwmages.jpg', '2025-04-10 11:21:03', 2),
(12, 'photo', '../uploads/Orphan-Care-3-scaled.jpg', '2025-04-10 11:21:09', 2),
(13, 'photo', '../uploads/orphan-care-programs.jpg', '2025-04-10 11:21:14', 2),
(14, 'photo', '../uploads/orphans.jpg', '2025-04-10 11:21:20', 2),
(15, 'photo', '../uploads/s.jpg', '2025-04-10 11:21:25', 2),
(16, 'photo', '../uploads/water-project.jpeg', '2025-04-10 11:21:31', 2);

-- --------------------------------------------------------

--
-- Table structure for table `needs`
--

CREATE TABLE `needs` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `child_id` int(11) DEFAULT NULL,
  `need_type` enum('Food','Education','Maintenance') NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('Pending','Fulfilled') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `posted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `posted_at`, `admin_id`) VALUES
(3, 'Hope and Healing at Matri Chaya: Rajshahi’s Beacon of Care for Orphans', 'Rajshahi, Bangladesh – April 10, 2025\r\n\r\nIn the heart of Rajshahi, a city known for its educational and cultural heritage, a small orphanage named Matri Chaya is making a big impact. With its name meaning “Mother’s Shelter,” Matri Chaya is more than just a home for children without parents—it’s a sanctuary of love, hope, and opportunity.\r\n\r\nFounded in 2012 by a group of local social workers and philanthropists, Matri Chaya currently houses over 60 children ranging in age from 3 to 18. The orphanage offers more than just shelter—it provides a nurturing environment, education, healthcare, and emotional support to help children grow into confident, capable individuals.\r\n\r\n“We wanted to create a place where every child feels safe and loved,” says Shamsun Nahar, the director of Matri Chaya. “Many of these children have faced unimaginable hardships. Our goal is to give them a second chance at life.”\r\n\r\nThe children attend nearby public schools and are encouraged to participate in extracurricular activities like music, painting, and sports. Volunteers from local colleges often visit to offer tutoring and mentorship, helping bridge the gap between institutional care and personal attention.\r\n\r\nThe orphanage runs largely on donations from kind-hearted individuals and community organizations. Local businesses in Rajshahi often contribute food, clothes, and educational materials, while international NGOs have occasionally supported infrastructure development.\r\n\r\nRecently, Matri Chaya launched a campaign called “Sponsor a Smile”, aiming to connect donors directly with the children they support. The initiative has already seen encouraging participation from both local residents and members of the Bangladeshi diaspora.\r\n\r\nDespite its limited resources, the spirit of Matri Chaya remains strong.\r\n\r\n“When I came here, I didn’t know what love was,” says 12-year-old Rashed, one of the children. “Now I have brothers, sisters, and a family. I want to grow up and help other kids like me.”\r\n\r\nAs Rajshahi continues to grow and modernize, institutions like Matri Chaya remind us that the true measure of a community lies in how it treats its most vulnerable. With ongoing support, this little haven of hope promises to brighten the lives of many more children in the years to come.', '2025-04-10 10:58:46', 2);

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `posted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `title`, `content`, `posted_at`, `admin_id`) VALUES
(3, 'Matri Chaya Orphanage, Rajshahi', 'Date: April 10, 2025\r\n\r\nWe are pleased to inform our well-wishers, donors, and members of the community that Matri Chaya Orphanage is currently expanding its services and welcoming new admissions for orphaned and vulnerable children.\r\n\r\nAs part of our commitment to providing a safe, nurturing, and educational environment, we are also seeking donations, volunteers, and sponsorships under our ongoing campaign “Sponsor a Smile”.\r\n\r\nHow You Can Help:\r\n\r\nDonate clothes, books, or non-perishable food items\r\n\r\nSponsor a child’s education or healthcare\r\n\r\nVolunteer your time for teaching, mentoring, or recreational activities\r\n\r\nInterested individuals or organizations are requested to contact us at the following:\r\n\r\n📞 Phone: +8801301566986\r\n📧 Email: matrichaya.orphanage@gmail.com\r\n📍 Address: Matri Chaya Orphanage, Shaheb Bazar, Rajshahi, Bangladesh\r\n\r\nLet us work together to build a better future for these children. Your support can make a world of difference.\r\n\r\n– Matri Chaya Management Committee', '2025-04-10 11:00:14', 2),
(4, 'Matri Chaya Orphanage, Rajshahi', 'Date: April 10, 2025\r\n\r\nWe are pleased to inform our well-wishers, donors, and members of the community that Matri Chaya Orphanage is currently expanding its services and welcoming new admissions for orphaned and vulnerable children.\r\n\r\nAs part of our commitment to providing a safe, nurturing, and educational environment, we are also seeking donations, volunteers, and sponsorships under our ongoing campaign “Sponsor a Smile”.\r\n\r\nHow You Can Help:\r\n\r\nDonate clothes, books, or non-perishable food items\r\n\r\nSponsor a child’s education or healthcare\r\n\r\nVolunteer your time for teaching, mentoring, or recreational activities\r\n\r\nInterested individuals or organizations are requested to contact us at the following:\r\n\r\n📞 Phone: +8801301566986\r\n📧 Email: matrichaya.orphanage@gmail.com\r\n📍 Address: Matri Chaya Orphanage, Shaheb Bazar, Rajshahi, Bangladesh\r\n\r\nLet us work together to build a better future for these children. Your support can make a world of difference.\r\n\r\n– Matri Chaya Management Committee', '2025-04-10 11:13:54', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','branch','user') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `phone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `phone`) VALUES
(11, 'Muhammad', 'raj@mc.org', '$2y$10$cvbjQJ7Sor9sJoQT5yHNSOnr2rGBh3f2V7fVFqiY8u.9OYRyvF81W', 'branch', '2025-04-14 04:25:50', 1725917055),
(12, 'Abdul', 'dha@mc.org', '$2y$10$mSjZXLD9Fdhto6alLVAh8OumzBJkRhY98sO4jcPCXugS2M.OsHcs6', 'branch', '2025-04-14 04:29:48', 1745698721),
(13, 'Mehedi', 'khul@mc.org', '$2y$10$Lq5SsPxLGTVug3Goyc7mke.K7uSb20akvd37XnhQEVnmZTyFQ7iV6', 'branch', '2025-04-14 04:32:08', 1745698458),
(14, 'Rasel Hossen', 'mymen@mc.org', '$2y$10$c9I8P6TjUm5mNPKfrYCuIOZ3a6icsNhJRkhz0K.9b8eCO7DEu2pPO', 'branch', '2025-04-14 04:34:03', 1645698721),
(15, 'Masud Azad', 'chatto@mc.org', '$2y$10$fekp.7ME7e0wEOKQMHusOO2lNsvT2atVQRAn.6on6My8ctUE8.N9q', 'branch', '2025-04-14 04:35:45', 1945698721),
(16, 'Kamrul Anik', 'rang@mc.org', '$2y$10$CG24VZA7RMwJWEzAIbvDHek9tUEzimu9VNW.gAxmunepmpTm6c/6i', 'branch', '2025-04-14 04:37:27', 1845698721),
(17, 'Ahmed Saleh', 'bar@mc.org', '$2y$10$NY2/V62/FwwGhw/NC4FdwOWD2xgGUMxxT8OHWavoidyIFWsUgXGXK', 'branch', '2025-04-14 04:39:51', 1304643912),
(18, 'Mehedi Das', 'sy@mc.org', '$2y$10$7/m4mkJ61g.OjF52/8IeoONCmE9gWTMG8E1p83jb40eKpSFfwcrUa', 'branch', '2025-04-14 04:42:16', 1928706008),
(19, 'Atik', 'atik@gmail.com', '$2y$10$H1cnoPT8eQCOq15O915Ayem04jRsIBGOTQzlieVDwBb6SPlcO/4WK', 'user', '2025-04-14 14:55:41', 1746568977);

-- --------------------------------------------------------

--
-- Table structure for table `users1`
--

CREATE TABLE `users1` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adoption_requests`
--
ALTER TABLE `adoption_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `child_id` (`child_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `adoption_requests_ibfk_1` (`user_id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branch_admin`
--
ALTER TABLE `branch_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `children`
--
ALTER TABLE `children`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `donations_ibfk_1` (`user_id`);

--
-- Indexes for table `fund_requests`
--
ALTER TABLE `fund_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `needs`
--
ALTER TABLE `needs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `child_id` (`child_id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users1`
--
ALTER TABLE `users1`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `adoption_requests`
--
ALTER TABLE `adoption_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `branch_admin`
--
ALTER TABLE `branch_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `children`
--
ALTER TABLE `children`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fund_requests`
--
ALTER TABLE `fund_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `needs`
--
ALTER TABLE `needs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users1`
--
ALTER TABLE `users1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `adoption_requests`
--
ALTER TABLE `adoption_requests`
  ADD CONSTRAINT `adoption_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `adoption_requests_ibfk_2` FOREIGN KEY (`child_id`) REFERENCES `children` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `adoption_requests_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `children`
--
ALTER TABLE `children`
  ADD CONSTRAINT `children_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `donations`
--
ALTER TABLE `donations`
  ADD CONSTRAINT `donations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `donations_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fund_requests`
--
ALTER TABLE `fund_requests`
  ADD CONSTRAINT `fund_requests_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `gallery`
--
ALTER TABLE `gallery`
  ADD CONSTRAINT `gallery_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `needs`
--
ALTER TABLE `needs`
  ADD CONSTRAINT `needs_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `needs_ibfk_2` FOREIGN KEY (`child_id`) REFERENCES `children` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `news_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notices`
--
ALTER TABLE `notices`
  ADD CONSTRAINT `notices_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
