<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch counts
$total_branches = $conn->query("SELECT COUNT(*) AS count FROM branches")->fetch_assoc()['count'];
$total_children = $conn->query("SELECT COUNT(*) AS count FROM children")->fetch_assoc()['count'];
$total_adoptions = $conn->query("SELECT COUNT(*) AS count FROM adoption_requests WHERE status = 'Approved'")->fetch_assoc()['count'];
$total_donations = $conn->query("SELECT SUM(amount) AS total FROM donations WHERE status = 'Approved'")->fetch_assoc()['total'];
$total_fund_requests = $conn->query("SELECT COUNT(*) AS count FROM fund_requests WHERE status = 'Pending'")->fetch_assoc()['count'];

// Fetch admin details
$admin_id = $_SESSION['admin_id'];
$admin = $conn->query("SELECT * FROM admins WHERE id = $admin_id")->fetch_assoc();
?>
<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
<div class="container mt-5">
    <h2>Admin Dashboard</h2>

    <div class="row">
        <div class="col-md-3">
            <div class="card text-bg-primary mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Branches</h5>
                    <h3><?= $total_branches; ?></h3>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-bg-success mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Children</h5>
                    <h3><?= $total_children; ?></h3>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-bg-warning mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Adoptions</h5>
                    <h3><?= $total_adoptions; ?></h3>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-bg-info mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Donations</h5>
                    <h3>$<?= $total_donations ?: '0'; ?></h3>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-bg-danger mb-3">
                <div class="card-body">
                    <h5 class="card-title">Pending Fund Requests</h5>
                    <h3><?= $total_fund_requests; ?></h3>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include "footer.php";
?>