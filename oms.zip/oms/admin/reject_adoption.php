<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id']) || !isset($_GET['id'])) {
    header("Location: manage_adoptions.php");
    exit();
}

$id = $_GET['id'];
$sql = "UPDATE adoption_requests SET status = 'Rejected', approved_at = NOW(), decided_by = {$_SESSION['admin_id']} WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    header("Location: manage_adoptions.php?success=Request rejected!");
} else {
    echo "Error: " . $conn->error;
}
?>
