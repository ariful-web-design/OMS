<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $phone = trim($_POST['phone']); // Ensure phone number is collected
    $role = $_POST['role'];

    // Validate role
    $valid_roles = ['admin', 'branch', 'user'];
    if (!in_array($role, $valid_roles)) {
        $error = "Invalid role selected.";
    } else {
        // Insert user
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, phone, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssis", $name, $email, $password, $phone, $role);

        if ($stmt->execute()) {
            $stmt->close();

            // If role is 'branch', insert into branches table
            if ($role == 'branch') {
                $branch_name = trim($_POST['branch_name']);
                $location = trim($_POST['location']);

                if (!empty($branch_name) && !empty($location)) {
                    $stmt_branch = $conn->prepare("INSERT INTO branches (name, location) VALUES (?, ?)");
                    $stmt_branch->bind_param("ss", $branch_name, $location);
                    
                    if ($stmt_branch->execute()) {
                        $stmt_branch->close();
                        header("Location: manage_users.php?success=Branch & User added successfully!");
                        exit();
                    } else {
                        $error = "Error adding branch: " . $stmt_branch->error;
                    }
                } else {
                    $error = "Branch Name and Location are required for branch role.";
                }
            } else {
                header("Location: manage_users.php?success=User added successfully!");
                exit();
            }
        } else {
            $error = "Error adding user: " . $stmt->error;
            $stmt->close();
        }
    }
}
?>
<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>

<head>
    <script>
        function toggleBranchFields() {
            var role = document.getElementById("role").value;
            var branchFields = document.getElementById("branchFields");
            if (role === "branch") {
                branchFields.style.display = "block";
            } else {
                branchFields.style.display = "none";
            }
        }
    </script>
</head>

<div class="container mt-5">
    <h2>Add New User</h2>
    <?php if (isset($error)) { echo "<p class='text-danger'>$error</p>"; } ?>
    <form method="POST">
        <div class="mb-3">
            <label>Name:</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Email:</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Phone:</label>
            <input type="text" name="phone" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password:</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Role:</label>
            <select name="role" id="role" class="form-control" onchange="toggleBranchFields()" required>
                <option value="admin">Admin</option>
                <option value="branch">Branch</option>
                <option value="user">General User</option>
            </select>
        </div>

        <!-- Branch Fields (Visible only when Role = Branch) -->
        <div id="branchFields" style="display: none;">
            <h4>Branch Details</h4>
            <div class="mb-3">
                <label>Branch Name:</label>
                <input type="text" name="branch_name" class="form-control">
            </div>
            <div class="mb-3">
                <label>Location:</label>
                <input type="text" name="location" class="form-control">
            </div>
        </div>

        <button type="submit" class="btn btn-success">Add User</button>
    </form>
</div>
<?php
include "footer.php";
?>
