<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$result = $conn->query("SELECT * FROM branches");
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
<div class="container mt-5">
    <h2>Manage Branches</h2>
    <a href="add_branch.php" class="btn btn-primary mb-3">Add New Branch</a>
    <?php if (isset($_GET['success'])) { echo "<p class='text-success'>" . $_GET['success'] . "</p>"; } ?>
    <table class="table table-bordered">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Location</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['id']; ?></td>
                <td><?= $row['name']; ?></td>
                <td><?= $row['location']; ?></td>
                <td>
                    <a href="edit_branch.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="delete_branch.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php
include "footer.php";
?>
