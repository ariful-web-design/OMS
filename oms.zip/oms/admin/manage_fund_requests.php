<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$result = $conn->query("SELECT fr.id, b.name AS branch_name, fr.amount, fr.purpose, fr.status 
                        FROM fund_requests fr
                        JOIN branches b ON fr.branch_id = b.id
                        WHERE fr.status = 'Pending'");



?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
<div class="container mt-5">
    <h2>Manage Fund Requests</h2>
    <table class="table table-bordered">
        <thead class="table-primary">
            <tr>
                <th>Branch</th>
                <th>Amount</th>
                <th>Purpose</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['branch_name']; ?></td>
                    <td>$<?= $row['amount']; ?></td>
                    <td><?= $row['need_type']; ?></td>
                    <td><?= $row['status']; ?></td>
                    <td>
                        <a href="approve_fund_request.php?id=<?= $row['id']; ?>" class="btn btn-success">Approve</a>
                        <a href="reject_fund_request.php?id=<?= $row['id']; ?>" class="btn btn-danger">Reject</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php
include "footer.php";
?>
