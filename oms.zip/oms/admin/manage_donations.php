<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$result = $conn->query("SELECT d.id, u.username AS donor_name, b.name AS branch_name, d.amount, d.status, d.donation_date 
                        FROM donations d
                        JOIN users u ON d.user_id = u.id
                        JOIN branches b ON d.branch_id = b.id
                        WHERE d.status = 'Pending'");

?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
<div class="container mt-5">
    <h2>Manage Donations</h2>
    <table class="table table-bordered">
        <thead class="table-primary">
            <tr>
                <th>Donor</th>
                <th>Branch</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['donor_name']; ?></td>
                    <td><?= $row['branch_name']; ?></td>
                    <td>$<?= $row['amount']; ?></td>
                    <td><?= $row['status']; ?></td>
                    <td>
                        <a href="approve_donation.php?id=<?= $row['id']; ?>" class="btn btn-success">Approve</a>
                        <a href="reject_donation.php?id=<?= $row['id']; ?>" class="btn btn-danger">Reject</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php
include "footer.php";
?>