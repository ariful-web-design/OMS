<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: manage_users.php");
    exit();
}

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM users WHERE id = $id");
$user = $result->fetch_assoc();

// Fetching branch details if role is 'branch'
$branch = null;
if ($user['role'] == 'branch') {
    $branch_result = $conn->query("SELECT * FROM branches WHERE name = (SELECT name FROM branches WHERE id = $id)"); // Assuming there's a relationship
    $branch = $branch_result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = isset($_POST['username']) ? $_POST['username'] : $user['username']; // Default to existing name if not set
    $phone = isset($_POST['phone']) ? $_POST['phone'] : $user['phone']; // Default to existing name if not set
    $email = isset($_POST['email']) ? $_POST['email'] : $user['email']; // Default to existing email if not set
    $role = isset($_POST['role']) ? $_POST['role'] : $user['role']; // Default to existing role if not set

    // Update user details
    $sql = "UPDATE users SET username = '$name', phone = '$phone', email = '$email', role = '$role' WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        // If role is branch, update branch details
        if ($role == 'branch') {
            $branch_name = isset($_POST['branch_name']) ? $_POST['branch_name'] : $branch['name'];
            $location = isset($_POST['location']) ? $_POST['location'] : $branch['location'];

            if (!empty($branch_name) && !empty($location)) {
                // If branch details are provided, update them
                $update_branch_sql = "UPDATE branches SET name = '$branch_name', location = '$location' WHERE id = $id";
                $conn->query($update_branch_sql);
            }
        }
        header("Location: manage_users.php?success=User updated successfully!");
        exit();
    } else {
        $error = "Error updating user: " . $conn->error;
    }
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
<head>
    <script>
        function toggleBranchFields() {
            var role = document.getElementById("role").value;
            var branchFields = document.getElementById("branchFields");
            if (role === "branch") {
                branchFields.style.display = "block";
            } else {
                branchFields.style.display = "none";
            }
        }

        // Show branch fields if the current user is a branch
        window.onload = function() {
            toggleBranchFields(); // Ensures the correct visibility state when the page loads
        };
    </script>
</head>
<div class="container mt-5">
    <h2>Edit User</h2>
    <?php if (isset($error)) { echo "<p class='text-danger'>$error</p>"; } ?>
    <form method="POST">
        <div class="mb-3">
            <label>Name:</label>
            <input type="text" name="username" value="<?= isset($_POST['username']) ? $_POST['username'] : $user['username']; ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Email:</label>
            <input type="email" name="email" value="<?= isset($_POST['email']) ? $_POST['email'] : $user['email']; ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Phone:</label>
            <input type="int" name="phone" value="<?= isset($_POST['phone']) ? $_POST['phone'] : $user['phone']; ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Role:</label>
            <select name="role" id="role" class="form-control" onchange="toggleBranchFields()" required>
                <option value="admin" <?= isset($_POST['role']) && $_POST['role'] == 'admin' ? 'selected' : ($user['role'] == 'admin' ? 'selected' : ''); ?>>Admin</option>
                <option value="branch" <?= isset($_POST['role']) && $_POST['role'] == 'branch' ? 'selected' : ($user['role'] == 'branch' ? 'selected' : ''); ?>>Branch</option>
                <option value="user" <?= isset($_POST['role']) && $_POST['role'] == 'user' ? 'selected' : ($user['role'] == 'user' ? 'selected' : ''); ?>>General User</option>
            </select>
        </div>

        <!-- Branch Fields (Visible only when Role = Branch) -->
        <div id="branchFields" style="display: <?= isset($_POST['role']) && $_POST['role'] == 'branch' || $user['role'] == 'branch' ? 'block' : 'none'; ?>;">
            <h4>Branch Details</h4>
            <div class="mb-3">
                <label>Branch Name:</label>
                <input type="text" name="branch_name" value="<?= isset($_POST['branch_name']) ? $_POST['branch_name'] : ($branch['name'] ?? ''); ?>" class="form-control">
            </div>
            <div class="mb-3">
                <label>Location:</label>
                <input type="text" name="location" value="<?= isset($_POST['location']) ? $_POST['location'] : ($branch['location'] ?? ''); ?>" class="form-control">
            </div>
        </div>

        <button type="submit" class="btn btn-success">Update User</button>
    </form>
</div>
<?php
include "footer.php";
?>
