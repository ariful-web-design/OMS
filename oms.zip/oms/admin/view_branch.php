<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}


include '../db.php';

// Fetch branches with their respective users
$query = "
    SELECT b.id, b.name AS branch_name, u.username AS branch_user, b.created_at 
    FROM branches b 
    LEFT JOIN users u ON b.id = u.id 
    WHERE u.role = 'branch'
";
$result = $conn->query($query);
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>

<div class="container">
    <h2>Branch List</h2>
    <a href="manage_users.php" class="btn btn-primary mb-3">Back</a>
    <table class="table table-bordered">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Branch Name</th>
                <th>Branch User</th>
                <th>Created Time</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php $count = 1; ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $count++; ?></td>
                        <td><?= htmlspecialchars($row['branch_name']); ?></td>
                        <td><?= htmlspecialchars($row['branch_user']); ?></td>
                        <td><?= date("d M Y, h:i A", strtotime($row['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">No branches found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
include "footer.php";
?>
