
    <div class="sidebar">
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="manage_adoptions.php">Manage Adoptions</a>
    <a href="manage_donations.php">Manage Donations</a>
    <a href="manage_fund_requests.php">Manage Fund Requests</a>
    <a href="manage_users.php">Manage User</a>
    <a href="view_children.php">View Child</a>
    <a href="admin_profile.php">Profile</a>
    <a href="post.php">Update Home Page</a>
    </div>

