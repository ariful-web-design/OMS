<?php
include "../db.php";

// Fetch children with related branch names
$sql = "SELECT children.id, children.name AS child_name, children.age, children.gender, children.photo, children.adoption_status, branches.name AS branch_name 
        FROM children 
        JOIN branches ON children.branch_id = branches.id";
$result = $conn->query($sql);
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container mt-5">
        <h2 class="mb-4">Children List</h2>
        <table class="table table-bordered">
        <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Photo</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Adoption Status</th>
                    <th>Branch</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td>
                            <?php if (!empty($row['photo'])) { ?>
                                <img src="../uploads/<?php echo $row['photo']; ?>" alt="Child Photo" width="50">
                            <?php } else { echo "No Photo"; } ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['child_name']); ?></td>
                        <td><?php echo $row['age']; ?></td>
                        <td><?php echo $row['gender']; ?></td>
                        <td><?php echo $row['adoption_status']; ?></td>
                        <td><?php echo htmlspecialchars($row['branch_name']); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
<?php
include "footer.php";
?>
