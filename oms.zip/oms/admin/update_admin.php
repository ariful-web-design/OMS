<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_id = $_POST['admin_id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE admins SET username='$username', email='$email', password='$hashed_password' WHERE id=$admin_id";
    } else {
        $sql = "UPDATE admins SET username='$username', email='$email' WHERE id=$admin_id";
    }

    if ($conn->query($sql) === TRUE) {
        header("Location: admin_profile.php?success=Profile updated!");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
