<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id']) || !isset($_GET['id'])) {
    header("Location: manage_fund_requests.php");
    exit();
}

$id = intval($_GET['id']); // Sanitize input
$admin_id = intval($_SESSION['admin_id']); // Sanitize admin ID

$sql = "UPDATE fund_requests SET status = 'Approved', approved_at = NOW(), decided_by = ? WHERE id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $admin_id, $id);

if ($stmt->execute()) {
    header("Location: manage_fund_requests.php?success=Fund request approved!");
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
