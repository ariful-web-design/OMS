<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id']) || !isset($_GET['id'])) {
    header("Location: manage_donations.php");
    exit();
}

$id = $_GET['id'];
$sql = "UPDATE donations SET status = 'Rejected', donation_date = NOW(), decided_by = {$_SESSION['admin_id']} WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    header("Location: manage_donations.php?success=Donation rejected!");
} else {
    echo "Error: " . $conn->error;
}
?>
