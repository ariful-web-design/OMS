<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$admin = $conn->query("SELECT * FROM admins WHERE id = $admin_id")->fetch_assoc();
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>

<div class="container mt-5">
    <h2>Admin Profile</h2>
    <form action="admin_dashboard.php" method="POST">
        <input type="hidden" name="admin_id" value="<?= $admin['id']; ?>">

        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" class="form-control" name="username" value="<?= $admin['username']; ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" name="email" value="<?= $admin['email']; ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">New Password (Leave blank to keep current)</label>
            <input type="password" class="form-control" name="password">
        </div>

        <button type="submit" class="btn btn-primary">Update Profile</button>
        <a href="admin_dashboard.php" class="btn btn-secondary">Back</a>
    </form>
</div>
<?php
include "footer.php";
?>