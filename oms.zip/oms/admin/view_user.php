<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include '../db.php';

// Fetch all users
$query = "SELECT id, username, email, phone, role, created_at FROM users ORDER BY created_at DESC";
$result = $conn->query($query);
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>

<div class="container">
    <h2>User List</h2>
    <a href="manage_users.php" class="btn btn-primary mb-3">Back</a>
    <table class="table table-bordered">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Role</th>
                <th>Created Time</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php $count = 1; ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $count++; ?></td>
                        <td><?= htmlspecialchars($row['username']); ?></td>
                        <td><?= htmlspecialchars($row['email']); ?></td>
                        <td><?= htmlspecialchars($row['phone']); ?></td>
                        <td>
                            <span class="role-badge <?= htmlspecialchars($row['role']); ?>">
                                <?= ucfirst($row['role']); ?>
                            </span>
                        </td>
                        <td><?= date("d M Y, h:i A", strtotime($row['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">No users found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
include "footer.php";
?>
