<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
include '../db.php';

$id = $_GET['id'];

// Check if the user has the 'branch' role
$result = $conn->query("SELECT role FROM users WHERE id=$id");
$user = $result->fetch_assoc();

if ($user['role'] === 'branch') {
    // If the user is a branch, delete the branch (based on another condition such as 'name' or 'location')
    // For now, let's assume that the 'name' or 'location' of the branch is used to identify the branch to be deleted
    $conn->query("DELETE FROM branches WHERE name = 'some_name'"); // Modify this query based on your requirement
}

// Now, delete the user from the users table
$conn->query("DELETE FROM users WHERE id=$id");

header("Location: manage_users.php");
exit();
?>
