<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: manage_branches.php");
    exit();
}

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM branches WHERE id = $id");
$branch = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $location = $_POST['location'];

    $sql = "UPDATE branches SET name = '$name', location = '$location' WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        header("Location: manage_branches.php?success=Branch updated successfully!");
        exit();
    } else {
        $error = "Error updating branch: " . $conn->error;
    }
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
<div class="container mt-5">
    <h2>Edit Branch</h2>
    <?php if (isset($error)) { echo "<p class='text-danger'>$error</p>"; } ?>
    <form method="POST">
        <div class="mb-3">
            <label>Branch Name:</label>
            <input type="text" name="name" value="<?= $branch['name']; ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Location:</label>
            <input type="text" name="location" value="<?= $branch['location']; ?>" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Update Branch</button>
    </form>
</div>
<?php
include "footer.php";
?>
