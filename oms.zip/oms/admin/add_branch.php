<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $location = $_POST['location'];

    $sql = "INSERT INTO branches (name, location) VALUES ('$name', '$location')";
    if ($conn->query($sql) === TRUE) {
        header("Location: manage_branches.php?success=Branch added successfully!");
        exit();
    } else {
        $error = "Error adding branch: " . $conn->error;
    }
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
<div class="container mt-5">
    <h2>Add New Branch</h2>
    <?php if (isset($error)) { echo "<p class='text-danger'>$error</p>"; } ?>
    <form method="POST">
        <div class="mb-3">
            <label>Branch Name:</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Location:</label>
            <input type="text" name="location" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Add Branch</button>
    </form>
</div>
<?php
include "footer.php";
?>
