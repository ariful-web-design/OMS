<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$result = $conn->query("SELECT ar.id, u.username as user_name, c.name as child_name, ar.status 
                        FROM adoption_requests ar
                        JOIN users u ON ar.user_id = u.id
                        JOIN children c ON ar.child_id = c.id
                        WHERE ar.status = 'Pending'");

?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
<div class="container mt-5">
    <h2>Manage Adoption Requests</h2>
    <table class="table table-bordered">
        <thead class="table-primary">
            <tr>
                <th>User</th>
                <th>Child</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['user_name']; ?></td>
                    <td><?= $row['child_name']; ?></td>
                    <td><?= $row['status']; ?></td>
                    <td>
                        <a href="approve_adoption.php?id=<?= $row['id']; ?>" class="btn btn-success">Approve</a>
                        <a href="reject_adoption.php?id=<?= $row['id']; ?>" class="btn btn-danger">Reject</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php
include "footer.php";
?>
