<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
// Handle News Submission
if (isset($_POST['post_news'])) {
    $title = $_POST['news_title'];
    $content = $_POST['news_content'];
    $admin_id = $_SESSION['admin_id']; // Get admin ID from session

    $stmt = $conn->prepare("INSERT INTO news (title, content, admin_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $title, $content, $admin_id);
    $stmt->execute();
    $stmt->close();
}

// Handle Notice Submission
if (isset($_POST['post_notice'])) {
    $title = $_POST['notice_title'];
    $content = $_POST['notice_content'];
    $admin_id = $_SESSION['admin_id'];

    $stmt = $conn->prepare("INSERT INTO notices (title, content, admin_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $title, $content, $admin_id);
    $stmt->execute();
    $stmt->close();
}

// Handle Gallery Upload
if (isset($_POST['upload_media'])) {
    $media_type = $_POST['media_type'];
    $admin_id = $_SESSION['admin_id'];

    // Upload file
    $target_dir = "../uploads/";
    $file_name = basename($_FILES["media_file"]["name"]);
    $target_file = $target_dir . $file_name;
    move_uploaded_file($_FILES["media_file"]["tmp_name"], $target_file);

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO gallery (media_type, media_url, admin_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $media_type, $target_file, $admin_id);
    $stmt->execute();
    $stmt->close();
}
?>

<?php
include "header.php";
?>
<div>
<?php
include "sidebar.php";
?>
</div>
    <div class="container mt-5">
        <h2>Post News, Notices & Media</h2>

        <!-- News Form -->
        <form method="POST" class="mb-4">
            <h3>Post News</h3>
            <input type="text" name="news_title" class="form-control mb-2" placeholder="News Title" required>
            <textarea name="news_content" class="form-control mb-2" placeholder="News Content" required></textarea>
            <button type="submit" name="post_news" class="btn btn-primary">Post News</button>
        </form>

        <!-- Notices Form -->
        <form method="POST" class="mb-4">
            <h3>Post Notice</h3>
            <input type="text" name="notice_title" class="form-control mb-2" placeholder="Notice Title" required>
            <textarea name="notice_content" class="form-control mb-2" placeholder="Notice Content" required></textarea>
            <button type="submit" name="post_notice" class="btn btn-warning">Post Notice</button>
        </form>

        <!-- Gallery Upload Form -->
        <form method="POST" enctype="multipart/form-data">
            <h3>Upload Media</h3>
            <select name="media_type" class="form-control mb-2" required>
                <option value="photo">Photo</option>
                <option value="video">Video</option>
            </select>
            <input type="file" name="media_file" class="form-control mb-2" required>
            <button type="submit" name="upload_media" class="btn btn-success">Upload</button>
        </form>
    </div>
<?php
include "footer.php";
?>
