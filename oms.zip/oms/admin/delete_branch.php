<?php
session_start();
include "../db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: manage_branches.php");
    exit();
}

$id = $_GET['id'];
$sql = "DELETE FROM branches WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    header("Location: manage_branches.php?success=Branch deleted successfully!");
    exit();
} else {
    echo "Error deleting branch: " . $conn->error;
}
?>
