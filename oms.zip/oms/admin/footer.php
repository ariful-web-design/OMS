
 <footer class="footer">
        <p>&copy; 2025 Matri Chaya. All Rights Reserved.</p>
    </footer>
</body>
</html>
