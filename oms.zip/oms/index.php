<?php
session_start(); 
include "db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        /* Navbar styling */
.navbar {
    background-color: #007bff !important;
}

.navbar-brand {
    color: white !important;
    font-weight: bold;
    font-size: 24px;
    letter-spacing: 1px;
    transition: color 0.3s ease, transform 0.3s ease;
}

.cover {
    width: 100%;
    margin-right: auto;
    margin-left: auto;
    padding-left: 200px;
}

.navbar-brand:hover {
    color: #ffcc00 !important; 
    transform: scale(1.1);
}

.navbar-nav {
    margin-left: auto;
}

/* Navigation link styling */
.nav-link {
    color: white !important;
    font-size: 18px;
    font-weight: 500;
    letter-spacing: 0.5px;
    transition: color 0.3s ease, transform 0.3s ease;
}

.nav-link:hover {
    color: #ffcc00 !important; /* Yellow hover effect */
    transform: scale(1.1); /* Slight scale effect on hover */
}

.nav-link.active {
    color: #ffcc00 !important; /* Active link color */
    font-weight: bold; /* Make active link bold */
}

.nav-item {
    margin-right: 15px; /* Spacing between nav items */
}

.navbar-toggler-icon {
    background-color: white; /* Change color of hamburger icon */
}
        }
        .section-title {
            color: #007bff;
        }
        .user-info {
            color: white;
            font-weight: bold;
        }
        .logo img {
            height: 100px;
            width: 100px;
            border-radius: 50%;
            border: 6px solid black;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <div class="logo">
            <img src="logoo.png" alt="OMS Logo">
        </div>
        <h2>Matri Chaya</h2>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                
                <?php if (isset($_SESSION['username'])): ?>
                    <li class="nav-item">
                        <span class="nav-link user-info"> <?= $_SESSION['username']; ?></span>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="user/user_logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="user/user_signup.php">Signup</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Sidebar -->
<div>
    <?php include "sidebar.php"; ?>
</div>
<div>
<img src="cover.png" class="cover">
</div>

<!-- Main Content -->
<div class="container mt-4">
        <!-- News Section -->
        <section id="news">
            <h2 class="section-title">Latest News</h2>
            <div id="news-content">Loading news...</div>
        </section>

        <!-- Notices Section -->
        <section id="notices" class="mt-4">
            <h2 class="section-title">Notices</h2>
            <div id="notice-content">Loading notices...</div>
        </section>

        <!-- Gallery Section -->
        <section id="gallery" class="mt-4">
            <h2 class="section-title">Photo & Video Gallery</h2>
            <div id="gallery-content" class="row">Loading gallery...</div>
        </section>
    </div>

    <script>
        // Fetch news
        fetch("fetch_news.php")
            .then(response => response.json())
            .then(data => {
                const newsContent = document.getElementById("news-content");
                newsContent.innerHTML = data.map(item => `
                    <div class="news-item mb-3">
                        <h5>${item.title}</h5>
                        <p>${item.content}</p>
                        <small>Posted on ${new Date(item.posted_at).toLocaleDateString()}</small>
                    </div>
                `).join('');
            })
            .catch(error => console.error("Error fetching news:", error));

        // Fetch notices
        fetch("fetch_notices.php")
            .then(response => response.json())
            .then(data => {
                const noticeContent = document.getElementById("notice-content");
                noticeContent.innerHTML = data.map(item => `
                    <div class="notice-item mb-3">
                        <h5>${item.title}</h5>
                        <p>${item.content}</p>
                        <small>Posted on ${new Date(item.posted_at).toLocaleDateString()}</small>
                    </div>
                `).join('');
            })
            .catch(error => console.error("Error fetching notices:", error));

// Fetch gallery items
fetch("fetch_gallery.php")
    .then(response => response.json())
    .then(data => {
        const galleryContent = document.getElementById("gallery-content");
        galleryContent.innerHTML = data.map(item => `
            <div class="col-md-4 gallery-item">
                ${item.media_type === "photo" ? `
                    <img src="uploads/${item.media_url}" alt="${item.media_url}" class="img-fluid">
                ` : `
                    <video controls class="img-fluid">
                        <source src="uploads/${item.media_url}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                `}
            </div>
        `).join('');
    })
    .catch(error => console.error("Error fetching gallery items:", error));

    </script>

<?php include "footer.php"; ?>